#include "xc.h"
#define _XTAL_FREQ 20000000
#define FCY 8000000UL
#include <libpic30.h>

// Configuration settings
//#pragma config FOSC = FRC        // Internal Fast RC oscillator
#pragma config FWDTEN = OFF      // Watchdog Timer disabled
#pragma config JTAGEN = OFF      // JTAG port disabled
#pragma config FNOSC = FRCPLL    // Fast RC oscillator with PLL

#define LED_PIN   LATAbits.LATA9
#define BUTTON_PIN  PORTCbits.RC8

void initIO(void);

int main(void) {
    initIO();

    while (1) {
        // Check if the button is pressed
        if (BUTTON_PIN == 0) {
            // Turn on the LED
            LED_PIN = 1;
        } else {
            // Turn off the LED
            LED_PIN = 0;
        }
//        LED_PIN = 1;
//        __delay_ms(5000);
//        LED_PIN = 0;
//        __delay_ms(5000);

        // Add a small delay to debounce the button
//        __delay_ms(1000);
    }

    return 0;
}


void initIO(void) {
    // Set RA9 (LED) as output
    TRISAbits.TRISA9 = 0;

    // Set RC8 (Button) as input
    TRISCbits.TRISC8 = 1;

    // Initial state: turn off the LED
    LED_PIN = 0;
}

//void delay_ms(unsigned int milliseconds) {
//    unsigned int i, j;
//    for (i = 0; i < milliseconds; i++)
//        for (j = 0; j < 16000; j++);  // Adjust this loop for the desired delay
//}
