/*
 * File:   timer.c
 * Author: achal
 *
 * Created on 16 January, 2024, 2:39 PM
 */
#include "xc.h"
#define _XTAL_FREQ 8000000
#define FCY 8000000UL
#define BRGVAL ((FCY/BAUDRATE)/16)-1
#define BAUDRATE 9600 // Replace this with your desired baud rate
#include <libpic30.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// CONFIG4
#pragma config DSWDTPS = DSWDTPS1F      //  (1:68719476736 (25.7 Days))
#pragma config DSWDTOSC = LPRC          //  (DSWDT uses LPRC as reference clock)
#pragma config DSBOREN = OFF            // Deep Sleep BOR Enable bit (DSBOR Disabled)
#pragma config DSWDTEN = OFF            // Deep Sleep Watchdog Timer Enable (DSWDT Disabled)
#pragma config DSSWEN = OFF             // DSEN Bit Enable (Deep Sleep operation is always disabled)
#pragma config PLLDIV = PLL4X           // USB 96 MHz PLL Prescaler Select bits (4x PLL selected)
#pragma config I2C1SEL = DISABLE        // Alternate I2C1 enable bit (I2C1 uses SCL1 and SDA1 pins)
#pragma config IOL1WAY = OFF            // PPS IOLOCK Set Only Once Enable bit (The IOLOCK bit can be set and cleared using the unlock sequence)

// CONFIG3
#pragma config WPFP = WPFP127           // Write Protection Flash Page Segment Boundary (Page 127 (0x1FC00))
#pragma config SOSCSEL = ON             // SOSC Selection bits (SOSC circuit selected)
#pragma config WDTWIN = PS25_0          // Window Mode Watchdog Timer Window Width Select (Watch Dog Timer Window Width is 25 percent)
#pragma config PLLSS = PLL_FRC          // PLL Secondary Selection Configuration bit (PLL is fed by the on-chip Fast RC (FRC) oscillator)
#pragma config BOREN = ON               // Brown-out Reset Enable (Brown-out Reset Enable)
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable (Disabled)
#pragma config WPCFG = WPCFGDIS         // Write Protect Configuration Page Select (Disabled)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select (Write Protect from WPFP to the last page of memory)

// CONFIG2
#pragma config POSCMD = NONE            // Primary Oscillator Select (Primary Oscillator Disabled)
#pragma config WDTCLK = LPRC            // WDT Clock Source Select bits (WDT uses LPRC)
#pragma config OSCIOFCN = OFF           // OSCO Pin Configuration (OSCO/CLKO/RA3 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSECMD           // Clock Switching and Fail-Safe Clock Monitor Configuration bits (Clock switching enabled, Fail-Safe Clock Monitor disabled)
#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
#pragma config ALTCMPI = CxINC_RB       // Alternate Comparator Input bit (C1INC is on RB13, C2INC is on RB9 and C3INC is on RA0)
#pragma config WDTCMX = WDTCLK          // WDT Clock Source Select bits (WDT clock source is determined by the WDTCLK Configuration bits)
#pragma config IESO = OFF               // Internal External Switchover (Disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler Select (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler Ratio Select (1:128)
#pragma config WINDIS = OFF             // Windowed WDT Disable (Standard Watchdog Timer)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT disabled in hardware; SWDTEN bit disabled)
#pragma config ICS = PGx1               // Emulator Pin Placement Select bits (Emulator functions are shared with PGEC1/PGED1)
#pragma config LPCFG = OFF              // Low power regulator control (Disabled - regardless of RETEN)
#pragma config GWRP = OFF               // General Segment Write Protect (Write to program memory allowed)
#pragma config GCP = OFF                // General Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (Disabled)

#define IR_Sensor  PORTCbits.RC4
#define IR_OUTPUT  LATBbits.LATB8
#define btn_0      0x5F6050AF
#define btn_1      0x5F60807F
#define btn_2      0x5F6040BF
#define btn_3      0x5F60C03F
#define btn_4      0x5F6020DF
#define btn_5      0x5F60A05F
#define btn_6      0x5F60609F
#define btn_7      0x5F6050AF
#define btn_8      0x5F6010EF
#define btn_9      0x5F60906F 
#define blue_btn   0x5F60C23D
#define power_btn  0x5F60F00F



uint32_t ir_code;
uint16_t count = 0;
uint8_t bit = 0;
uint32_t RemoteCommand = 0;
uint8_t cmd;
uint8_t cmdli;
uint8_t RemoteFlag = 0;

void configureTimer(void);
void initIO(void);

////////////////////////////////////////////////////////////////////////////////

int main(void) {
    
    // Initialize
    initIO();
    configureTimer();
    IR_OUTPUT = 1;
//    LATAbits.LATA9 = !LATAbits.LATA9;

    while (1) {
         if (RemoteFlag) {
            if (RemoteCommand == power_btn) {
                sendIRSignal(RemoteCommand);  // Retransmit the IR signal
            }
            else if(RemoteCommand == btn_0)
            {
                sendIRSignal(RemoteCommand);
            }
            else if(RemoteCommand == btn_1)
            {
                sendIRSignal(RemoteCommand);
            }
            else if(RemoteCommand == btn_2)
            {
                sendIRSignal(RemoteCommand);
            }
            else if(RemoteCommand == blue_btn)
            {
                sendIRSignal(RemoteCommand);
            }

            RemoteFlag = 0;  // Clear the flag
        }
    }

    return 0;
}

void initIO(void)
{
    TRISAbits.TRISA9 = 0;
    TRISAbits.TRISA10 = 0;
    TRISBbits.TRISB8 = 0;
    TRISCbits.TRISC4 = 1;
    
    __builtin_write_OSCCONL(OSCCON & 0xbf); 
    RPINR0bits.INT1R = 20;
    __builtin_write_OSCCONL(OSCCON | 0x40);
    
    IPC5bits.INT1IP = 1;        // Set interrupt priority
    IFS1bits.INT1IF = 0;        // Clear interrupt flag
    
    IEC1bits.INT1IE = 1;        // Enable interrupt
    INTCON2bits.INT1EP = 1;     // Interrupt on falling edge
     __builtin_enable_interrupts();
}


void __attribute__((__interrupt__, __auto_psv__)) _INT1Interrupt(void)
{
    IFS1bits.INT1IF = 0;            // Clear the interrupt flag
//    LATAbits.LATA10 = !LATAbits.LATA10;
    
    if (count > 160) {
    ir_code = 0;                    // Reset the IR code
    bit = 0;
    count = 0;
    } else {
        // Check for the space after the start pulse (logic low)
        if (count > 34) {          // Adjusted for logical '1'
            // Process a logic 0 bit
            ir_code <<= 1;         // Shift left
            ir_code |= 1;          // Set the least significant bit
            bit++;
            count = 0; 
        } else if (count > 20) {    // Adjusted for logical '0'
            // Process a logic 1 bit
            ir_code <<= 1;          //Shift left
            bit++;
            count = 0;
        }
    }

    if (bit == 32) { 
            RemoteCommand = ir_code;
            RemoteFlag = 1;
            if (ir_code == power_btn) {
                LATAbits.LATA9 = !LATAbits.LATA9;
            }
            else if(ir_code == btn_0)
            {
                LATAbits.LATA9 = !LATAbits.LATA9;
            }
            else if(ir_code == btn_1)
            {
                LATAbits.LATA9 = !LATAbits.LATA9;
            }
            

        count = 0;
        bit = 0;
    }

}

void sendIRSignal(uint32_t cmd)
{
    
    IR_OUTPUT = 0;
    delay_us(9000);
    IR_OUTPUT = 1;
    delay_us(4500);
    
    // Iterate through the bits of the command
    for (int i = 0; i < 32; i++) {
        
        // Extract each bit from the command
        uint32_t bitValue = (cmd >> (31 - i)) & 0x01;

        if (bitValue) {
            // If the bit is 1, send a 1-bit burst
            IR_OUTPUT = 0;
            delay_us(560);
            IR_OUTPUT = 1;
            delay_us(1690); // Space after 1-bit burst
        } else {
            // If the bit is 0, send a 0-bit space
            IR_OUTPUT = 0;
            delay_us(560);
            IR_OUTPUT = 1;  // Space after 0-bit space
            delay_us(560);
        }
    }
    
    //send the stop burst
    IR_OUTPUT = 0;
    delay_us(560);
    IR_OUTPUT = 1;
       
}



void configureTimer(void) {
    
    T1CONbits.TON = 0;      // Turn off Timer1 during configuration
    T1CONbits.TCS = 0;      // Select internal clock (Fosc/2)
    T1CONbits.TCKPS = 0b10; // Set prescaler to 1:64

    uint32_t timerTicks = (FCY * 50) / (1000000 * 64);
 
    TMR1 = 0;                               // Clear Timer1
    PR1 = (uint16_t)(timerTicks - 1);       // Set period register

    // Configure Timer1 interrupt
    IPC0bits.T1IP = 2;      // Set Timer1 interrupt priority
    IFS0bits.T1IF = 0;      // Clear Timer1 interrupt flag
    IEC0bits.T1IE = 1;      // Enable Timer1 interrupt
  
    T1CONbits.TON = 1;      // Turn on Timer1
}

void delay_us(uint16_t microsecond)
{
    T2CONbits.TON = 0;      // Turn off Timer2 during configuration
    TMR2 = 0;
//    T2CONbits.TCS = 0;      // Select internal clock (Fosc/2)
    
    uint32_t timerTicks = microsecond * (FCY /1000000);
    timerTicks = timerTicks/64;

    PR2 = (uint16_t)(timerTicks);       // Set period register
    
    T2CONbits.TCKPS = 0b10; // Set prescaler to 1:64
    T2CONbits.TON = 1;      // Turn on Timer2
//    while (TMR2 < PR2);
    while (IFS0bits.T2IF == 0);
    
    T2CONbits.TON = 0;  
    IFS0bits.T2IF = 0;
}


// Interrupt Service Routine (ISR) for Timer1
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void) {
    
    count++;    
    IFS0bits.T1IF = 0;    // Clear Timer1 interrupt flag
}
