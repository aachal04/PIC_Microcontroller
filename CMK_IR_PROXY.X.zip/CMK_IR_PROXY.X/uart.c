/*
 * File:   uart.c
 * Author: achal
 *
 * Created on 10 January, 2024, 12:20 PM
 */

#include "xc.h"
#include "config.h"
#include "sys_init.h"
#include "IR_Sig_Decode.h"

extern char arr_index;

void UART_Write_String(char *text)
{
  int i;
  for(i=0;i< (strlen(text));i++)
    UART_Write(text[i]);
}

void UART_Write(char data)
{
    while(U1STAbits.UTXBF);
    U1TXREG = data;
}

// Function to receive a character via UART
char UART_Read() {
    char temp;
    while (!U1STAbits.URXDA);
    temp = U1RXREG;
    return temp;
}

void UART_Write_Int(int value) {
    char recv_value = (char)value;
    char buffer[20];
    sprintf(buffer, "%c", recv_value);
    UART_Write_String(buffer);
}


void __attribute__((interrupt, no_auto_psv)) _U1RXInterrupt(void) {
        
    static int i = 0;
    static int receive = 0;
    char recv_data;
    char recv_buff[11];

    if(U1STAbits.URXDA)
    {
        recv_data = U1RXREG;
        
        if(recv_data == '['){
            memset(recv_buff, '\0', sizeof(recv_buff));
            i = 0;
            receive = 1;
        }
        if(receive)
        {
            if(recv_data == 'n')
            {
                recv_buff[i] = '\0';
                receive = 0;
                i = 0;
                
                sprintf(recv_buff, '%s', recv_data);
                
                parse_data(recv_buff);
            }
            else
            {
                recv_buff[i++] = recv_data; 
            } 
        }
    }
    IFS0bits.U1RXIF = 0;       
}

void parse_data(char * cmnd) {
    char str_value1[4];
    str_value1[0] = cmnd[1];
    str_value1[1] = cmnd[2];
    str_value1[2] = cmnd[3];
    str_value1[3] = '\0';                              
    
    char str_value2[2];
    str_value2[0] = cmnd[5];
    str_value2[1] = '\0'; 
    
    
    if (strcmp(str_value1, "VOL") == 0 && str_value2[0] == 'U') {
        VOLUME_UP = 1;
        __delay_ms(25);
        VOLUME_UP = 0;
        __delay_ms(25);
    }
    else if(strcmp(str_value1, "VOL") == 0 && str_value2[0] == 'D')
    {
        VOLUME_DOWN = 1;
        __delay_ms(25);
        VOLUME_DOWN = 0;
        __delay_ms(25);
    }
    else if(strcmp(str_value1, "VOL") == 0 && str_value2[0] == 'M')
    {
        VOLUME_MUTE_OUT = 1;
        __delay_ms(1000);
    }
    else if(strcmp(str_value1, "VOL") == 0 && str_value2[0] == 'E')
    {
        VOLUME_MUTE_OUT = 0;
        __delay_ms(1000);
    }
    else if(strcmp(str_value1, "PWR") == 0 && str_value2[0] == '1')
    {
        SYSTEM_PWR_STATE = 1;
    }
    else if(strcmp(str_value1, "PWR") == 0 && str_value2[0] == '0')
    {
        SYSTEM_PWR_STATE = 0;
    }
}

 
void UART_Send_String(const char *cmd, int value) {
    UART_Write('[');
    UART_Write_String(cmd);
    UART_Write(',');
    UART_Write_Int(value);
    UART_Write(']');
//    UART_Write('\\');
//    UART_Write('r');
//    UART_Write('\\');
//    UART_Write('n');
}


