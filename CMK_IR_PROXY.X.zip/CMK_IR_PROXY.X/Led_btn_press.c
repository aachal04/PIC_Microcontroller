#include "xc.h"
#include "config.h"

void initIO(void);

int main(void) {
    initIO();

    while (1) {
        // Check if the button is pressed
//        if (BUTTON_PIN == 0) {
//            // Turn on the LED
//            LED_PIN = 1;
//        } else {
//            // Turn off the LED
//            LED_PIN = 0;
//        }
        LED_PIN = 1;
        __delay_ms(1000);
        LED_PIN = 0;
        __delay_ms(1000);

    }

    return 0;
}


