/*
 * File:   interrupt.c
 * Author: achal
 *
 * Created on 9 February, 2024, 3:24 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
