/*
 * File:   timer.c
 * Author: achal
 *
 * Created on 16 January, 2024, 2:39 PM
 */
#include "xc.h"
#include "config.h"
#include "uart.h"
#include "sys_init.h"
#define ARRAY_SIZE 5
#define POWER_OFF_STATE 0
#define POWER_ON_STATE 1

uint32_t ir_code;
uint16_t count = 0;
uint8_t bit = 0;
uint32_t RemoteCommand = 0;
uint8_t cmd;
uint8_t cmdli;
uint8_t RemoteFlag = 0;

char array[ARRAY_SIZE] = {'V','D','A','H','T'};
static char arr_index = 0;
char Vol_modein_flag = 0;

uint8_t SYSTEM_POWER_STATE = POWER_OFF_STATE;
uint8_t VOLUME_MUTE = 0; // Initialize to muted state

void configureTimer(void);

////////////////////////////////////////////////////////////////////////////////

void IR_Signal()
{
    check_volume_mode();

    if (RemoteFlag) {
        if (SYSTEM_POWER_STATE == POWER_OFF_STATE && RemoteCommand == power_btn) {
            // Process POWER button IR message in powered-off state
            UART_Write_String("[PWR,1]");
            SYSTEM_POWER_STATE = POWER_ON_STATE;
            VOLUME_MUTE = 0; // Unmute volume
            RemoteFlag = 0;
        } else if (SYSTEM_POWER_STATE == POWER_ON_STATE) {
            // Process IR messages in powered-on state
            switch (RemoteCommand) {
                case power_btn:
                    UART_Write_String("[PWR,0]");
                    SYSTEM_POWER_STATE = POWER_OFF_STATE;
                    VOLUME_MUTE = 1; // Mute volume
                    break;
                case vol_plus:
                    if (VOLUME_MUTE == 1) {
                        // Transition to Unmuted state
                        UART_Write_String("[VOL,U]");
                        VOLUME_MUTE = 0; // Unmute volume

                    } else {
                        // Process VOL+ button IR message
                        volume_up();
                    }
                    break;
                case vol_minus:
                    if (VOLUME_MUTE == 1) {
                        // Transition to Unmuted state
                        UART_Write_String("[VOL,D]");
                        VOLUME_MUTE = 0; // Unmute volume
                        
                    } else {
                        // Process VOL- button IR message
                        volume_down();
                    }
                    break;
                case mute_btn:
                    toggle_volume_mute();
                    break;
                case source_btn:
                    UART_Send_String("INP", array[arr_index]);
                    arr_index = (arr_index + 1) % ARRAY_SIZE;
                    break;
                default:
                    // Check HDMI_1_SEL2 status to determine if IR message should be processed
                    process_IR_messages(HDMI_1_SEL2);
                    break;
            }
            RemoteFlag = 0;
        }
    }
}

// Function to check Volume Mode indicator
void check_volume_mode(void) {
    if (VOLUME_MODEIND == 0) {
        // VOLUME_MODEIND is 0, transmit pulse
        transmit_volume_pulse();
    }
}

// Function to transmit a pulse to return VOLUME_MODEIND to logic ?1?
void transmit_volume_pulse(void) {
    VOLUME_MODE = 1; // Set VOLUME_MODE pin to logic '1'
    __delay_ms(25); // Delay for 25ms
    VOLUME_MODE = 0; // Clear VOLUME_MODE pin
}

// Function to toggle volume mute state
void toggle_volume_mute(void) {
    if (VOLUME_MUTE == 0) {
        VOLUME_MUTE = 1; // Mute volume
        volume_mute_serial_message(1);
    } else {
        VOLUME_MUTE = 0; // Unmute volume
        volume_mute_serial_message(0);
    }
}

// Function to send volume mute state over serial interface
void volume_mute_serial_message(uint8_t mute_state) {
    if (mute_state == 1) {
        UART_Write_String("[VOL,MUTE]");
    } else {
        UART_Write_String("[VOL,UNMUTE]");
    }
}

// Function to handle volume up action
void volume_up(void) {
    // Process VOL+ IR message
    VOLUME_UP = 1;  // Set VOLUME_UP pin to logic '1' to transmit pulse
    __delay_ms(25); // Delay for 25ms
    VOLUME_UP = 0;
}

// Function to handle volume down action
void volume_down(void) {
    // Process VOL- IR message
    VOLUME_DOWN = 1;  // Set VOLUME_UP pin to logic '1' to transmit pulse
    __delay_ms(25);   // Delay for 25ms
    VOLUME_DOWN = 0;
}

// Function to process IR messages based on HDMI_1_SEL2 status
void process_IR_messages(uint8_t HDMI_1_SEL2_status) {
    if (HDMI_1_SEL2_status == 0) {
        // HDMI_1_SEL2 is '0', process POWER, SOURCE, VOL+, VOL-, and MUTE button IR messages
        IR_Signal();
    } else {
        // HDMI_1_SEL2 is '1', process all IR messages
        IR_Signal();
    }
}


void __attribute__((__interrupt__, __auto_psv__)) _INT1Interrupt(void)
{
    IFS1bits.INT1IF = 0;            // Clear the interrupt flag
    LATAbits.LATA10 = !LATAbits.LATA10;
    
    if (count > 160) {
    ir_code = 0;                    // Reset the IR code
    bit = 0;
    count = 0;
    } else {
        // Check for the space after the start pulse (logic low)
        if (count > 34) {          // Adjusted for logical '1'
            // Process a logic 0 bit
            ir_code <<= 1;         // Shift left
            ir_code |= 1;          // Set the least significant bit
            bit++;
            count = 0; 
        } else if (count > 20) {    // Adjusted for logical '0'
            // Process a logic 1 bit
            ir_code <<= 1;          //Shift left
            bit++;
            count = 0;
        }
    }

    if (bit == 32) { 
        cmdli = ~ir_code;
        cmd = ir_code >> 8;
        if (cmdli == cmd)
        {
            RemoteCommand = ir_code;
            RemoteFlag = 1;
            count = 0;
        }
        bit = 0;
    }

}

void sendIRSignal(uint32_t cmd)
{
    
    IR_OUTPUT = 0;
    delay_us(9000);
    IR_OUTPUT = 1;
    delay_us(4500);
    
    // Iterate through the bits of the command
    for (int i = 0; i < 32; i++) {
        
        // Extract each bit from the command
        uint32_t bitValue = (cmd >> (31 - i)) & 0x01;

        if (bitValue) {
            // If the bit is 1, send a 1-bit burst
            IR_OUTPUT = 0;
            delay_us(560);
            IR_OUTPUT = 1;
            delay_us(1690); // Space after 1-bit burst
        } else {
            // If the bit is 0, send a 0-bit space
            IR_OUTPUT = 0;
            delay_us(560);
            IR_OUTPUT = 1;  // Space after 0-bit space
            delay_us(560);
        }
    }
    
    //send the stop burst
    IR_OUTPUT = 0;
    delay_us(560);
    IR_OUTPUT = 1;
       
}


void configureTimer(void) {
    
    T1CONbits.TON = 0;      // Turn off Timer1 during configuration
    T1CONbits.TCS = 0;      // Select internal clock (Fosc/2)
    T1CONbits.TCKPS = 0b10; // Set prescaler to 1:64

    uint32_t timerTicks = (FCY * 50) / (1000000 * 64);
 
    TMR1 = 0;                               // Clear Timer1
    PR1 = (uint16_t)(timerTicks - 1);       // Set period register

    // Configure Timer1 interrupt
    IPC0bits.T1IP = 2;      // Set Timer1 interrupt priority
    IFS0bits.T1IF = 0;      // Clear Timer1 interrupt flag
    IEC0bits.T1IE = 1;      // Enable Timer1 interrupt
  
    T1CONbits.TON = 1;      // Turn on Timer1
}

void delay_us(uint16_t microsecond)
{
    T2CONbits.TON = 0;      // Turn off Timer2 during configuration
    T2CONbits.TCS = 0;      // Select internal clock (Fosc/2)
    T2CONbits.TCKPS = 0b10; // Set prescaler to 1:64

//    uint32_t timerTicks = (FCY * microsecond) / (1000000 * 64);
    uint32_t timerTicks = microsecond * (FCY /1000000);
    timerTicks = timerTicks/64;
 
    TMR2 = 0;                               // Clear Timer1
    PR2 = (uint16_t)(timerTicks - 1);       // Set period register
    
    
    T2CONbits.TON = 1;      // Turn on Timer2
    while (IFS0bits.T2IF == 0);
    
    T2CONbits.TON = 0;
    IFS0bits.T2IF = 0;
}


// Interrupt Service Routine (ISR) for Timer1
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void) {
    
    count++;    
    IFS0bits.T1IF = 0;    // Clear Timer1 interrupt flag
}
