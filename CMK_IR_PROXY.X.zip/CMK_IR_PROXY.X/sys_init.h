/* 
 * File:   sys_init.h
 * Author: achal
 *
 * Created on 12 February, 2024, 11:18 AM
 */

#ifndef SYS_INIT_H
#define	SYS_INIT_H

#ifdef	__cplusplus
extern "C" {
#endif

void UART_Init();
void initIO(void);


#ifdef	__cplusplus
}
#endif

#endif	/* SYS_INIT_H */

