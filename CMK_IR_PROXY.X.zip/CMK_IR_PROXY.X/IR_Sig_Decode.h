/* 
 * File:   IR_Sig_Decode.h
 * Author: achal
 *
 * Created on 12 February, 2024, 11:07 AM
 */

#ifndef IR_SIG_DECODE_H
#define	IR_SIG_DECODE_H

#ifdef	__cplusplus
extern "C" {
#endif
    
void IR_Signal();
void check_volume_mode(void);
void transmit_volume_pulse(void);
void toggle_volume_mute(void);
void volume_mute_serial_message(uint8_t mute_state);
void volume_up(void);
void volume_down(void);
void process_IR_messages(uint8_t HDMI_1_SEL2_status);
void sendIRSignal(uint32_t cmd);
void configureTimer(void);    
void delay_us(uint16_t microsecond);


#ifdef	__cplusplus
}
#endif

#endif	/* IR_SIG_DECODE_H */

