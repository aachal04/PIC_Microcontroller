/*
 * File:   main.c
 * Author: achal
 *
 * Created on 9 February, 2024, 3:03 PM
 */


#include "xc.h"
#include "config.h"
#include "IR_Sig_Decode.h"
#include "sys_init.h"
#include "uart.h"
//extern char arr_index;
int main(void) {
    initIO();
    configureTimer();
    UART_Init();
    IR_OUTPUT = 1;
    
//    UART_Send_String("VOL",'U');
//    UART_Send_String("VOL", 'U');
    
//    const char *message = "Glide tech pvt ltd @1234546";
//    UART_Write(message);
    
    while(1){
        
        IR_Signal();
        
    }
    return 0;
}





