/* 
 * File:   config.h
 * Author: achal
 *
 * Created on 9 February, 2024, 3:47 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif

#define _XTAL_FREQ 8000000
#define FCY 8000000UL
#define BRGVAL ((FCY/BAUDRATE)/16)-1
#define BAUDRATE 9600 // Replace this with your desired baud rate
#include <libpic30.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define LED_PIN             LATAbits.LATA9
#define LED_PIN2            LATAbits.LATA10
#define BUTTON_PIN          PORTCbits.RC8
#define HDMI_1_EN           PORTCbits.RC7
#define HDMI_1_SEL2         PORTAbits.RA7
#define HDMI_1_SEL          PORTCbits.RC0
    
#define VOLUME_MODEIND      PORTCbits.RC9
#define VOLUME_MODE         LATBbits.LATB9
#define VOLUME_MUTE_OUT     LATBbits.LATB10
#define VOLUME_MUTE_IN      PORTBbits.RB10
#define VOLUME_UP           LATAbits.LATA1
#define VOLUME_DOWN         LATAbits.LATA0

#define SYSTEM_PWR_STATE    PORTAbits.RA8   
#define IR_Sensor           PORTCbits.RC4
#define IR_OUTPUT           LATBbits.LATB8
    
//Remote Signals//    
#define btn_0      0x5F6050AF
#define btn_1      0x5F60807F
#define btn_2      0x5F6040BF
#define btn_3      0x5F60C03F
#define btn_4      0x5F6020DF
#define btn_5      0x5F60A05F
#define btn_6      0x5F60609F
#define btn_7      0x5F6050AF
#define btn_8      0x5F6010EF
#define btn_9      0x5F60906F 
#define blue_btn   0x5F60C23D
#define ch_minus   0x5F60F807
#define ch_plus    0x5F60D827
#define chlist_btn 0x5F60E817
#define res_btn    0x5F6002FD
#define dot_btn    0x5F60C837
#define epg_btn    0x5F60A857
#define exit_btn   0x5F6030CF
#define green_btn  0x5F608877
#define info_btn   0x5F60B847
#define menu_btn   0x5F6018E7
#define mts_audio  0x5F60708F
#define mute_btn   0x5F609867
#define ok_btn     0x5F6008F7
#define recall_btn 0x5F6038C7
#define red_btn    0x5F60D02F
#define sleep_btn  0x5F6042BD
#define source_btn 0x5F6048B7
#define txt_btn    0x5F60827D
#define vol_minus  0x5F607887
#define vol_plus   0x5F6058A7
#define yellow_btn 0x5F6022DD
#define zoom_btn   0x5F6028D7
#define power_btn  0x5F60F00F

#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_H */

