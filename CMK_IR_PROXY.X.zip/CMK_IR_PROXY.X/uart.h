/* 
 * File:   uart.h
 * Author: achal
 *
 * Created on 12 February, 2024, 12:03 PM
 */

#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif

void UART_Write_String(char *text);
void UART_Write(char data);
char UART_Read();
void UART_Write_Int(int value);
void parse_data(char * cmnd);
void UART_Send_String(const char *cmd, int value);

#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

